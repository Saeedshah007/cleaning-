(function () {
  "use strict";

  var PEOPLE = ["سعید", "خیبر", "وحید", "احسان"];
  var PCOLOR = { "سعید": "#c1622f", "خیبر": "#2f7a9a", "وحید": "#7a5fc4", "احسان": "#a3892f" };
  var TIER_LABELS = { light: "سبک", medium: "متوسط", heavy: "سنگین" };
  function colorFor(name) { return PCOLOR[name] || "var(--ink-faint)"; }

  // ---------- کمک‌توابع API ----------
  function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    opts.credentials = "same-origin";
    if (opts.body && typeof opts.body !== "string") opts.body = JSON.stringify(opts.body);
    return fetch("/api" + path, opts).then(function (res) {
      if (res.status === 401) { showLogin(); throw new Error("unauthenticated"); }
      return res.json().then(function (data) {
        if (!res.ok) { var e = new Error(data.error || "خطا"); e.status = res.status; e.data = data; throw e; }
        return data;
      });
    });
  }

  // ---------- toast ----------
  var toastTimer = null;
  function toast(msg) {
    var el = document.getElementById("toast");
    el.textContent = msg;
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("show"); }, 2600);
  }

  // ================= ورود =================
  var loginScreen = document.getElementById("loginScreen");
  var appEl = document.getElementById("app");
  var nameGrid = document.getElementById("nameGrid");
  var pinInput = document.getElementById("pinInput");
  var loginForm = document.getElementById("loginForm");
  var loginError = document.getElementById("loginError");
  var loginBtn = document.getElementById("loginBtn");
  var selectedName = null;

  PEOPLE.forEach(function (name) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "name-btn";
    btn.textContent = name;
    btn.addEventListener("click", function () {
      selectedName = name;
      nameGrid.querySelectorAll(".name-btn").forEach(function (b) { b.classList.toggle("active", b === btn); });
      pinInput.focus();
    });
    nameGrid.appendChild(btn);
  });

  loginForm.addEventListener("submit", function (ev) {
    ev.preventDefault();
    loginError.hidden = true;
    if (!selectedName) { loginError.textContent = "اول اسمت رو انتخاب کن."; loginError.hidden = false; return; }
    if (!pinInput.value) { loginError.textContent = "پینت رو بزن."; loginError.hidden = false; return; }
    loginBtn.disabled = true;
    fetch("/api/login", {
      method: "POST", credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: selectedName, pin: pinInput.value })
    }).then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
      .then(function (r) {
        loginBtn.disabled = false;
        if (!r.ok) { loginError.textContent = r.data.error || "ورود ناموفق بود."; loginError.hidden = false; return; }
        pinInput.value = "";
        showApp(r.data.name);
      }).catch(function () {
        loginBtn.disabled = false;
        loginError.textContent = "ارتباط با سرور برقرار نشد.";
        loginError.hidden = false;
      });
  });

  function showLogin() {
    appEl.hidden = true;
    loginScreen.hidden = false;
  }

  function showApp(name) {
    loginScreen.hidden = true;
    appEl.hidden = false;
    var chip = document.getElementById("userChip");
    chip.textContent = "👤 " + name + " · خروج";
    chip.onclick = function () {
      api("/logout", { method: "POST" }).then(function () { location.reload(); });
    };
    initAppOnce();
    refreshAll();
  }

  // ================= بوت =================
  fetch("/api/me", { credentials: "same-origin" }).then(function (res) {
    if (res.ok) return res.json().then(function (d) { showApp(d.name); });
    showLogin();
  }).catch(showLogin);

  // ================= تب‌ها =================
  var appInited = false;
  function initAppOnce() {
    if (appInited) return;
    appInited = true;

    var tabButtons = document.querySelectorAll(".tab-btn");
    var tabPanels = document.querySelectorAll(".tab-panel");
    function setActiveTab(tab) {
      var found = false;
      tabPanels.forEach(function (p) { if (p.getAttribute("data-tab") === tab) found = true; });
      if (!found) tab = "today";
      tabButtons.forEach(function (b) { b.classList.toggle("active", b.getAttribute("data-tab") === tab); });
      tabPanels.forEach(function (p) { p.hidden = p.getAttribute("data-tab") !== tab; });
      try { localStorage.setItem("cleaning-active-tab", tab); } catch (e) {}
      window.scrollTo(0, 0);
      loadTab(tab);
    }
    tabButtons.forEach(function (btn) {
      btn.addEventListener("click", function () { setActiveTab(btn.getAttribute("data-tab")); });
    });
    var savedTab = "today";
    try { savedTab = localStorage.getItem("cleaning-active-tab") || "today"; } catch (e) {}
    setActiveTab(savedTab);

    function positionTabbar() {
      var appbar = document.querySelector(".appbar");
      var tabbar = document.getElementById("tabbar");
      if (appbar && tabbar) tabbar.style.top = appbar.offsetHeight + "px";
    }
    positionTabbar();
    window.addEventListener("resize", positionTabbar);

    var infoBtn = document.getElementById("infoBtn");
    var infoOverlay = document.getElementById("infoOverlay");
    var infoClose = document.getElementById("infoClose");
    function openInfo() { infoOverlay.hidden = false; }
    function closeInfo() { infoOverlay.hidden = true; }
    infoBtn.addEventListener("click", openInfo);
    infoClose.addEventListener("click", closeInfo);
    infoOverlay.addEventListener("click", function (ev) { if (ev.target === infoOverlay) closeInfo(); });
    document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && !infoOverlay.hidden) closeInfo(); });

    var rosterInfo = [
      { name: "سعید", room: "اتاق مستر جدا · سرویس اختصاصی خودش", load: "light" },
      { name: "خیبر", room: "اتاق با سرویس بهداشتی مشترک", load: "heavy" },
      { name: "وحید", room: "اتاق با سرویس بهداشتی مشترک", load: "medium" },
      { name: "احسان", room: "اتاق با سرویس بهداشتی مشترک", load: "medium" }
    ];
    var rosterEl = document.getElementById("roster");
    rosterInfo.forEach(function (r) {
      var el = document.createElement("div");
      el.className = "person-card";
      el.innerHTML =
        '<div class="name"><span class="swatch" style="background:' + colorFor(r.name) + '"></span>' + r.name + '</div>' +
        '<div class="room">' + r.room + '</div>' +
        '<div class="load"><span class="wt wt-' + r.load + '">سهم ' + TIER_LABELS[r.load] + '</span></div>';
      rosterEl.appendChild(el);
    });

    var fineNameSel = document.getElementById("fineName");
    PEOPLE.forEach(function (name) {
      var opt = document.createElement("option");
      opt.value = name; opt.textContent = name;
      fineNameSel.appendChild(opt);
    });
    try { document.getElementById("fineDate").valueAsDate = new Date(); } catch (e) {}
    document.getElementById("fineForm").addEventListener("submit", function (ev) {
      ev.preventDefault();
      api("/fines", {
        method: "POST",
        body: {
          name: fineNameSel.value,
          role: document.getElementById("fineRole").value,
          reason: document.getElementById("fineReason").value.trim(),
          date: document.getElementById("fineDate").value,
          amount: 10
        }
      }).then(function () {
        document.getElementById("fineReason").value = "";
        loadFines();
        toast("جریمه ثبت شد.");
      }).catch(function (e) { toast(e.message || "خطا در ثبت جریمه"); });
    });

    updateDeadlineBadge();
    setInterval(updateDeadlineBadge, 30000);
    setupPush();

    window.__loadTab = loadTab;
  }

  function updateDeadlineBadge() {
    var now = new Date();
    var midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0);
    var totalMin = Math.max(0, Math.floor((midnight - now) / 60000));
    var h = Math.floor(totalMin / 60), m = totalMin % 60;
    var text = "⏰ تا نیمه‌شب: " + h + " ساعت و " + m + " دقیقه";
    ["deadlineBadge", "deadlineBadge2"].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.textContent = text;
    });
  }

  // ================= سازندهٔ دراپ‌باکس وضعیت =================
  var SIGN_OPTIONS = [
    { value: "", text: "— وضعیت —" },
    { value: "yes", text: "✅ شد" },
    { value: "no", text: "❌ نشد" }
  ];
  function buildSignSelect(key, status, locked, extraClass, onChanged) {
    var select = document.createElement("select");
    select.className = "sign-input" + (extraClass ? " " + extraClass : "");
    SIGN_OPTIONS.forEach(function (o) {
      var opt = document.createElement("option");
      opt.value = o.value; opt.textContent = o.text;
      select.appendChild(opt);
    });
    select.value = status || "";
    var lastConfirmed = select.value;
    function applyState() {
      select.classList.remove("sign-yes", "sign-no");
      if (select.value === "yes") select.classList.add("sign-yes");
      else if (select.value === "no") select.classList.add("sign-no");
    }
    applyState();
    if (locked) {
      select.disabled = true;
      select.classList.add("locked");
      select.title = "ددلاینش گذشته و جریمه لحاظ شده — دیگه قابل تغییر نیست.";
    }
    select.addEventListener("change", function () {
      var newVal = select.value;
      api("/mark", { method: "POST", body: { key: key, status: newVal } })
        .then(function () { lastConfirmed = newVal; applyState(); if (onChanged) onChanged(); })
        .catch(function (e) {
          toast(e.message || "خطا در ثبت وضعیت");
          select.value = lastConfirmed; // درخواست رد شد -> برگردون به آخرین مقدار تأییدشده
          if (e.status === 423) { select.disabled = true; select.classList.add("locked"); }
          applyState();
        });
    });
    return select;
  }

  // ================= بارگذاری تب‌ها =================
  function loadTab(tab) {
    if (tab === "today") loadToday();
    else if (tab === "daily") loadDaily();
    else if (tab === "weekly") loadWeekly();
    else if (tab === "biweekly") loadBiweekly();
    else if (tab === "monthly") loadMonthly();
    else if (tab === "fines") loadFines();
  }
  function refreshAll() { loadToday(); loadFines(); }

  var fmtFullFa;
  try { fmtFullFa = new Intl.DateTimeFormat("fa-IR-u-ca-gregory", { weekday: "long", day: "numeric", month: "long", year: "numeric" }); }
  catch (e) { fmtFullFa = new Intl.DateTimeFormat("fa-IR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }); }
  var fmtDayFa;
  try { fmtDayFa = new Intl.DateTimeFormat("fa-IR-u-ca-gregory", { day: "numeric", month: "long" }); }
  catch (e) { fmtDayFa = new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long" }); }
  var fmtMonthFa;
  try { fmtMonthFa = new Intl.DateTimeFormat("fa-IR-u-ca-gregory", { month: "long", year: "numeric" }); }
  catch (e) { fmtMonthFa = new Intl.DateTimeFormat("fa-IR", { month: "long", year: "numeric" }); }

  function isoToDate(iso) { var p = iso.split("-").map(Number); return new Date(p[0], p[1] - 1, p[2]); }

  function loadToday() {
    api("/today").then(function (d) {
      document.getElementById("todayDate").textContent = fmtFullFa.format(isoToDate(d.date));
      document.getElementById("startNote").textContent = d.isPreLaunch
        ? "برنامه از " + fmtFullFa.format(isoToDate(d.anchor)) + " شروع می‌شه — تا اون تاریخ، همون روز اول رو می‌بینی."
        : "برنامه در حال اجراست.";
      var grid = document.getElementById("todayGrid");
      grid.innerHTML = "";
      d.items.forEach(function (it) {
        var el = document.createElement("div");
        el.className = "today-item";
        el.innerHTML =
          '<div class="task"><span>' + it.label + '</span><span class="wt wt-' + it.tier + '">' + TIER_LABELS[it.tier] + '</span></div>' +
          '<div class="who" style="color:' + colorFor(it.doer) + '">' + it.doer + '</div>' +
          '<div class="who-check" style="color:' + colorFor(it.checker) + '">کنترل: ' + it.checker + '</div>';
        var row = document.createElement("div");
        row.className = "task-line";
        row.appendChild(buildSignSelect(it.doerKey, it.doerStatus, it.doerLocked));
        var row2 = document.createElement("div");
        row2.className = "task-line";
        row2.appendChild(buildSignSelect(it.checkerKey, it.checkerStatus, it.checkerLocked));
        el.appendChild(row);
        el.appendChild(row2);
        grid.appendChild(el);
      });
    });
    api("/snow").then(function (d) {
      var input = document.getElementById("snowDate");
      input.value = d.date || "";
      input.onchange = function () {
        api("/snow/date", { method: "POST", body: { date: input.value } }).then(function () { toast("تاریخ برف‌روبی ذخیره شد."); });
      };
      // امضای برف یه مسیر جدا داره (/snow/sign)، نه /mark عمومی — پس select‌هاش رو
      // جدا و مستقیم می‌سازیم (buildSignSelect عمومی همیشه به /mark پست می‌کنه).
      var wrap = document.getElementById("snowSigners");
      wrap.innerHTML = "";
      d.signers.forEach(function (s) {
        var row = document.createElement("div");
        row.className = "snow-signer";
        var label = document.createElement("span");
        label.className = "pname"; label.style.color = colorFor(s.name); label.textContent = s.name;
        row.appendChild(label);
        var select = document.createElement("select");
        select.className = "sign-input";
        SIGN_OPTIONS.forEach(function (o) {
          var opt = document.createElement("option");
          opt.value = o.value; opt.textContent = o.text;
          select.appendChild(opt);
        });
        select.value = s.status || "";
        function applyState() {
          select.classList.remove("sign-yes", "sign-no");
          if (select.value === "yes") select.classList.add("sign-yes");
          else if (select.value === "no") select.classList.add("sign-no");
        }
        applyState();
        select.addEventListener("change", function () {
          api("/snow/sign", { method: "POST", body: { name: s.name, status: select.value } })
            .then(applyState).catch(function (e) { toast(e.message || "خطا"); });
        });
        row.appendChild(select);
        wrap.appendChild(row);
      });
    });
  }

  function loadDaily() {
    api("/daily").then(function (d) {
      document.getElementById("dailyRange").textContent = "این هفته: " + fmtDayFa.format(isoToDate(d.weekStart)) + " تا " + fmtDayFa.format(isoToDate(d.weekEnd));
      var table = document.getElementById("dailyTable");
      table.innerHTML = "";
      var thead = document.createElement("thead");
      var headRow = document.createElement("tr");
      var headCells = "<th>روز</th>";
      d.days[0].cols.forEach(function (c) {
        headCells += '<th><div class="col-title">' + c.label + '</div><span class="wt wt-' + c.tier + '">' + TIER_LABELS[c.tier] + '</span></th>';
      });
      headRow.innerHTML = headCells;
      thead.appendChild(headRow);
      table.appendChild(thead);
      var tbody = document.createElement("tbody");
      d.days.forEach(function (day) {
        var tr = document.createElement("tr");
        if (day.isToday) tr.className = "is-today";
        var firstTd = document.createElement("td");
        firstTd.innerHTML = '<span class="day-name">' + day.dayName + '</span><span class="day-date">' + fmtDayFa.format(isoToDate(day.date)) + '</span>';
        tr.appendChild(firstTd);
        day.cols.forEach(function (col) {
          var td = document.createElement("td");
          var pill = document.createElement("span");
          pill.className = "who-pill"; pill.style.color = colorFor(col.doer); pill.textContent = col.doer;
          td.appendChild(pill);
          td.appendChild(buildSignSelect(col.doerKey, col.doerStatus, col.doerLocked, "cell-sign"));
          var checkPill = document.createElement("span");
          checkPill.className = "who-pill who-pill-check"; checkPill.style.color = colorFor(col.checker);
          checkPill.textContent = "کنترل: " + col.checker;
          td.appendChild(checkPill);
          td.appendChild(buildSignSelect(col.checkerKey, col.checkerStatus, col.checkerLocked, "cell-sign"));
          tr.appendChild(td);
        });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
    });
  }

  function renderPeriodCards(containerId, cards) {
    var container = document.getElementById(containerId);
    container.innerHTML = "";
    cards.forEach(function (item) {
      var card = document.createElement("div");
      card.className = "card";
      var head = document.createElement("div");
      head.className = "card-head";
      head.innerHTML = "<h3>" + item.title + "</h3>";
      var roles = document.createElement("div");
      roles.className = "roles";
      roles.innerHTML =
        '<div class="role-block"><span class="role-label">انجام</span><span class="who" style="color:' + colorFor(item.doer) + '">' + item.doer + '</span></div>' +
        '<div class="role-block"><span class="role-label">کنترل</span><span class="who-check" style="color:' + colorFor(item.checker) + '">' + item.checker + '</span></div>';
      head.appendChild(roles);
      card.appendChild(head);
      var meta = document.createElement("div");
      meta.className = "meta";
      meta.innerHTML = '<span class="wt wt-' + item.tier + '">' + TIER_LABELS[item.tier] + '</span>';
      card.appendChild(meta);
      item.tasks.forEach(function (t) {
        var wrap = document.createElement("div");
        wrap.className = "task-line";
        var text = document.createElement("span");
        text.className = "task-text"; text.textContent = t.text;
        wrap.appendChild(text);
        wrap.appendChild(buildSignSelect(t.key, t.status, t.locked));
        card.appendChild(wrap);
      });
      var verify = document.createElement("div");
      verify.className = "task-line verify-line";
      var vtext = document.createElement("span");
      vtext.className = "task-text"; vtext.textContent = "تأیید و کنترل نهایی (" + item.checker + ")";
      verify.appendChild(vtext);
      verify.appendChild(buildSignSelect(item.checkerKey, item.checkerStatus, item.checkerLocked));
      card.appendChild(verify);
      container.appendChild(card);
    });
  }

  function loadWeekly() {
    api("/weekly").then(function (d) {
      document.getElementById("weeklyRange").textContent = "هفتهٔ جاری: " + fmtDayFa.format(isoToDate(d.weekStart)) + " تا " + fmtDayFa.format(isoToDate(d.weekEnd));
      renderPeriodCards("weeklyCards", d.cards);
    });
  }
  function loadBiweekly() {
    api("/biweekly").then(function (d) {
      document.getElementById("biweeklyRange").textContent = "این دوهفته: " + fmtDayFa.format(isoToDate(d.biweekStart)) + " تا " + fmtDayFa.format(isoToDate(d.biweekEnd));
      renderPeriodCards("biweeklyCards", d.cards);
    });
  }
  function loadMonthly() {
    api("/monthly").then(function (d) {
      document.getElementById("monthlyRange").textContent = "ماه جاری: " + fmtMonthFa.format(isoToDate(d.monthLabel + "-01"));
      renderPeriodCards("monthlyCards", d.cards);
    });
  }

  function loadFines() {
    api("/fines").then(function (d) {
      var summary = document.getElementById("fineSummary");
      summary.innerHTML = "";
      PEOPLE.forEach(function (name) {
        var total = d.totals[name] || 0;
        var chip = document.createElement("div");
        chip.className = "fine-chip";
        chip.innerHTML = '<div class="fname" style="color:' + colorFor(name) + '">' + name + '</div><div class="famount">$' + total + '</div>';
        summary.appendChild(chip);
      });
      var list = document.getElementById("fineList");
      list.innerHTML = "";
      if (d.fines.length === 0) {
        var empty = document.createElement("div");
        empty.className = "fine-empty"; empty.textContent = "هنوز جریمه‌ای ثبت نشده.";
        list.appendChild(empty);
        return;
      }
      d.fines.forEach(function (f) {
        var row = document.createElement("div");
        row.className = "fine-row";
        row.innerHTML =
          '<span style="font-weight:700;color:' + colorFor(f.name) + '">' + f.name + '</span>' +
          '<span class="frole">' + (f.role === "انجام" ? "مسئول انجام" : "کنترل‌کننده") + '</span>' +
          (f.auto ? '<span class="fauto">⚙️ خودکار</span>' : '') +
          '<span class="freason">' + (f.reason || "—") + '</span>' +
          '<span class="fdate">' + (f.date || "") + '</span>' +
          '<span class="famt">$' + f.amount + '</span>';
        var delBtn = document.createElement("button");
        delBtn.type = "button"; delBtn.className = "fdel"; delBtn.textContent = "✕"; delBtn.title = "حذف این جریمه";
        delBtn.addEventListener("click", function () {
          api("/fines/" + f.id, { method: "DELETE" }).then(loadFines);
        });
        row.appendChild(delBtn);
        list.appendChild(row);
      });
    });
  }

  // ================= پوش نوتیفیکیشن =================
  function urlBase64ToUint8Array(base64String) {
    var padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    var base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    var raw = atob(base64);
    var arr = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
    return arr;
  }

  function setupPush() {
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) return;
    navigator.serviceWorker.register("/sw.js").then(function (reg) {
      return reg.pushManager.getSubscription().then(function (sub) {
        var banner = document.getElementById("pushBanner");
        if (!sub && Notification.permission !== "denied") {
          banner.hidden = false;
        }
        document.getElementById("pushEnableBtn").addEventListener("click", function () {
          enablePush(reg);
        });
      });
    }).catch(function () {});
  }

  function enablePush(reg) {
    api("/vapid-public-key").then(function (d) {
      if (!d.key) { toast("سرور هنوز کلید VAPID تنظیم نکرده."); return; }
      return Notification.requestPermission().then(function (perm) {
        if (perm !== "granted") { toast("اجازهٔ نوتیف داده نشد."); return; }
        return reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(d.key)
        }).then(function (sub) {
          return api("/push/subscribe", { method: "POST", body: sub.toJSON() });
        }).then(function () {
          document.getElementById("pushBanner").hidden = true;
          toast("نوتیف فعال شد ✅");
        });
      });
    }).catch(function (e) { toast(e.message || "فعال‌سازی نوتیف ناموفق بود"); });
  }

})();
