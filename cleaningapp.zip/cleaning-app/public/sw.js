// سرویس‌ورکر واقعی — چون از یه سرور واقعی سرو می‌شه (نه data:/blob: مثل آرتیفکت)،
// می‌تونه رویداد push رو حتی وقتی اپ بسته‌ست بگیره و نوتیف نشون بده.

const CACHE_NAME = "cleaning-app-v1";
const CORE_ASSETS = ["/", "/style.css", "/app.js", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// شبکه‌اول برای API، کش‌اول برای فایل‌های ثابت — اپ آفلاین هم باز می‌شه (با آخرین داده)
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith("/api/")) return; // API همیشه از شبکه
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});

self.addEventListener("push", (event) => {
  let data = { title: "چرخهٔ نظافت خانه", body: "یه بروزرسانی جدید داری." };
  try { if (event.data) data = event.data.json(); } catch (e) {}
  event.waitUntil(
    self.registration.showNotification(data.title || "چرخهٔ نظافت خانه", {
      body: data.body || "",
      icon: "/icons/icon192.png",
      badge: "/icons/icon192.png",
      dir: "rtl",
      lang: "fa"
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  event.waitUntil(
    self.clients.matchAll({ type: "window" }).then((clients) => {
      for (const c of clients) { if ("focus" in c) return c.focus(); }
      if (self.clients.openWindow) return self.clients.openWindow("/");
    })
  );
});
