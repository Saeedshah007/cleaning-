"use strict";
/** اجرا: npm run gen-vapid — یه‌بار برای همیشه، کلیدها رو توی .env بذار */
const webpush = require("web-push");
const keys = webpush.generateVAPIDKeys();
console.log("این دو تا رو توی فایل .env (و توی تنظیمات Render) بذار:\n");
console.log("VAPID_PUBLIC_KEY=" + keys.publicKey);
console.log("VAPID_PRIVATE_KEY=" + keys.privateKey);
