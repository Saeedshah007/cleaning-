"use strict";
/** اجرا: npm run reset-pin -- <اسم> <پین‌جدید> */
const bcrypt = require("bcryptjs");
const { init, client } = require("../src/db.js");
const { PEOPLE } = require("../src/rotation.js");

async function main() {
  const [name, pin] = process.argv.slice(2);
  if (!name || !pin || !PEOPLE.includes(name)) {
    console.error(`استفاده: npm run reset-pin -- <${PEOPLE.join("|")}> <پین‌جدید (۴ رقم)>`);
    process.exit(1);
  }
  await init();
  const hash = await bcrypt.hash(pin, 10);
  await client.execute({
    sql: "INSERT INTO users (name, pin_hash) VALUES (?, ?) ON CONFLICT(name) DO UPDATE SET pin_hash = excluded.pin_hash",
    args: [name, hash]
  });
  console.log(`پین ${name} به‌روز شد.`);
  process.exit(0);
}
main().catch((e) => { console.error(e); process.exit(1); });
