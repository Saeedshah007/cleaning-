"use strict";
/**
 * اجرا کن: npm run seed
 * برای هر ۴ نفر یه پین ۴ رقمی پیش‌فرض تصادفی می‌سازه (اگه قبلاً وجود نداشته باشن)
 * و رمزهای عبور رو چاپ می‌کنه — این تنها زمانیه که پین‌ها به‌صورت متن ساده دیده می‌شن،
 * پس همین‌جا یادداشتشون کن و به هر ۴ نفر بگو.
 */
const bcrypt = require("bcryptjs");
const { init, client } = require("../src/db.js");
const { PEOPLE } = require("../src/rotation.js");

function randPin() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

async function main() {
  await init();
  console.log("پین‌های اولیه (فقط همین یه بار همین‌جا نشون داده می‌شن):\n");
  for (const name of PEOPLE) {
    const existing = await client.execute({ sql: "SELECT name FROM users WHERE name = ?", args: [name] });
    if (existing.rows.length > 0) {
      console.log(`- ${name}: از قبل ثبت شده (پین عوض نشد)`);
      continue;
    }
    const pin = randPin();
    const hash = await bcrypt.hash(pin, 10);
    await client.execute({
      sql: "INSERT INTO users (name, pin_hash) VALUES (?, ?)",
      args: [name, hash]
    });
    console.log(`- ${name}: ${pin}`);
  }
  console.log("\nهر کس با اسم خودش + همین پین وارد می‌شه. اگه می‌خوای پین کسی رو عوض کنی: npm run reset-pin -- <اسم> <پین‌جدید>");
  process.exit(0);
}

main().catch((e) => { console.error("خطا در seed:", e); process.exit(1); });
