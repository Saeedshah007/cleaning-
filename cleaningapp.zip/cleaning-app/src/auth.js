"use strict";
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { client } = require("./db.js");
const { PEOPLE } = require("./rotation.js");

const COOKIE_NAME = "cleaning_session";
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET تنظیم نشده — یه رشتهٔ تصادفی طولانی توی env بذار (مثلاً با: openssl rand -hex 32)");
}

async function verifyLogin(name, pin) {
  if (!PEOPLE.includes(name)) return null;
  const res = await client.execute({ sql: "SELECT pin_hash FROM users WHERE name = ?", args: [name] });
  if (res.rows.length === 0) return null;
  const ok = await bcrypt.compare(String(pin), res.rows[0].pin_hash);
  return ok ? name : null;
}

function issueToken(name) {
  return jwt.sign({ name }, JWT_SECRET, { expiresIn: "180d" });
}

function setSessionCookie(res, name) {
  const token = issueToken(name);
  res.cookie(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 180 * 24 * 3600 * 1000
  });
}

function clearSessionCookie(res) {
  res.clearCookie(COOKIE_NAME);
}

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: "وارد نشدی" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (!PEOPLE.includes(payload.name)) throw new Error("bad user");
    req.user = payload.name;
    next();
  } catch (e) {
    return res.status(401).json({ error: "نشست نامعتبر یا منقضی‌شده" });
  }
}

module.exports = { COOKIE_NAME, verifyLogin, setSessionCookie, clearSessionCookie, requireAuth };
