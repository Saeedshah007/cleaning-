"use strict";
/**
 * این مسیر رو یه سرویس کرون رایگان بیرونی (مثل cron-job.org) هر ۱۰-۱۵ دقیقه صدا می‌زنه.
 * چون Render رایگان بعد از ۱۵ دقیقه بی‌کاری می‌خوابه، همین پینگ هم بیدارش نگه می‌داره و
 * هم موتور جریمه/یادآوری رو تیک می‌زنه. بدون CRON_SECRET درست، رد می‌شه.
 */
const express = require("express");
const engine = require("./engine.js");
const push = require("./push.js");
const { appNow } = require("./tz.js");

const router = express.Router();

router.all("/tick", async (req, res) => {
  const expected = process.env.CRON_SECRET;
  const provided = req.query.secret || req.get("X-Cron-Secret");
  if (!expected) return res.status(500).json({ error: "CRON_SECRET روی سرور تنظیم نشده" });
  if (provided !== expected) return res.status(403).json({ error: "دسترسی نداری" });

  const now = appNow();
  const fineResult = await engine.runAutoFineScan(now);
  const reminderResult = await engine.maybeSendEveningReminder(now);

  const allNotifications = [...fineResult.notifications, ...reminderResult.notifications];
  let pushSent = 0;
  for (const n of allNotifications) {
    const r = await push.sendToUser(n.userName, { title: n.title, body: n.body });
    pushSent += r.sent || 0;
  }

  res.json({
    ok: true,
    at: now.toISOString(),
    addedFines: fineResult.addedFines,
    reminderSent: reminderResult.sent,
    notificationsQueued: allNotifications.length,
    pushSent
  });
});

module.exports = router;
