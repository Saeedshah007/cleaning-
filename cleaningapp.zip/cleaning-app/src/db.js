"use strict";
/**
 * لایهٔ دیتابیس — روی libSQL (سازگار با SQLite). محلی: file:./data/dev.db
 * پروداکشن: یه دیتابیس رایگان Turso (لینک از طریق TURSO_DATABASE_URL/TURSO_AUTH_TOKEN).
 */
const { createClient } = require("@libsql/client");
const path = require("path");

const url = process.env.TURSO_DATABASE_URL || `file:${path.join(__dirname, "..", "data", "dev.db")}`;
const authToken = process.env.TURSO_AUTH_TOKEN || undefined;

const client = createClient(authToken ? { url, authToken } : { url });

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  name TEXT PRIMARY KEY,
  pin_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS task_marks (
  mark_key TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT '',
  updated_by TEXT,
  updated_at TEXT,
  locked INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS task_checkbox (
  box_key TEXT PRIMARY KEY,
  checked INTEGER NOT NULL DEFAULT 0,
  updated_by TEXT,
  updated_at TEXT
);

CREATE TABLE IF NOT EXISTS fines (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  role TEXT NOT NULL,
  reason TEXT,
  date TEXT,
  amount INTEGER NOT NULL DEFAULT 10,
  auto INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS autofined (
  mark_key TEXT PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id TEXT PRIMARY KEY,
  user_name TEXT NOT NULL,
  subscription_json TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reminder_log (
  reminder_key TEXT PRIMARY KEY,
  sent_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS snow (
  snow_date TEXT,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT '',
  PRIMARY KEY (name)
);
`;

async function init() {
  const stmts = SCHEMA.split(";").map((s) => s.trim()).filter(Boolean);
  for (const s of stmts) {
    await client.execute(s);
  }
}

module.exports = { client, init };
