"use strict";
/**
 * موتور اصلی: محاسبهٔ نماهای امروز/هفته/دوهفته/ماه + اسکن جریمهٔ خودکار و قفل کردن.
 * منطقش عیناً از تابع runAutoFines/applyLocks نسخهٔ آرتیفکت (که با jsdom تست شده) پورت شده،
 * با این تفاوت که این‌جا سرور مرجع نهایی حقیقته، نه localStorage مرورگر.
 */
const { client } = require("./db.js");
const R = require("./rotation.js");

async function loadAllMarks() {
  const res = await client.execute("SELECT mark_key, status, locked FROM task_marks");
  const map = new Map();
  for (const row of res.rows) map.set(row.mark_key, { status: row.status || "", locked: !!row.locked });
  return map;
}
async function loadAutofined() {
  const res = await client.execute("SELECT mark_key FROM autofined");
  return new Set(res.rows.map((r) => r.mark_key));
}

function getStatus(marks, key) {
  const m = marks.get(key);
  return m ? m.status : "";
}
function isLocked(marks, key) {
  const m = marks.get(key);
  return m ? !!m.locked : false;
}

/**
 * اسکن کامل: هرچی از ANCHOR تا "دیروز/دورهٔ کامل‌شدهٔ قبلی" هست و تأیید نشده،
 * جریمه‌ش رو ثبت می‌کنه، قفلش می‌کنه، و پیام‌های پوش لازم رو برمی‌گردونه (بدون ارسال —
 * ارسال با caller است تا این تابع تست‌پذیر و بدون وابستگی شبکه بمونه).
 */
async function runAutoFineScan(now) {
  const ctx = R.computeDateContext(now);
  const notifications = []; // {userName, title, body}
  if (!ctx.isPastAnchor) return { addedFines: 0, notifications };

  const marks = await loadAllMarks();
  const autofined = await loadAutofined();
  const newAutofined = [];
  const newFines = [];
  const newLocks = new Set();

  function considerFineIf(markKey, personName, role, reasonText, dateStr, isOk) {
    if (autofined.has(markKey)) return;
    newAutofined.push(markKey);
    autofined.add(markKey);
    if (!isOk) {
      newFines.push({
        id: "auto-" + markKey,
        name: personName,
        role,
        reason: reasonText,
        date: dateStr,
        amount: 10,
        auto: 1
      });
      notifications.push({
        userName: personName,
        title: "جریمهٔ خودکار ثبت شد",
        body: `${reasonText} — ${role === "انجام" ? "مسئول انجام" : "کنترل‌کننده"} بودی و تا ددلاین تأیید نشد. ۱۰ دلار جریمه شدی.`
      });
    }
  }

  // ---- روزانه ----
  let scanDay = new Date(R.ANCHOR);
  const lastFullDay = R.addDays(ctx.todayRaw, -1);
  while (scanDay.getTime() <= lastFullDay.getTime()) {
    const dIdx = R.toOurDay(scanDay.getDay());
    const wStartOfDay = R.addDays(scanDay, -dIdx);
    const wIdxOfDay = Math.round((wStartOfDay - ctx.anchorWeekStart) / (7 * 24 * 3600 * 1000));
    const dISO = R.dayKey(scanDay);
    R.DAILY_COLS.forEach((col) => {
      const doer = col.whoAt(dIdx, wIdxOfDay);
      const checker = col.checkerAt(dIdx, doer, wIdxOfDay);
      const doerKey = R.dailyDoerKey(wIdxOfDay, dIdx, col.key);
      const checkerKey = R.dailyCheckerKey(wIdxOfDay, dIdx, col.key);
      considerFineIf(doerKey, doer, "انجام", col.label + " — " + dISO, dISO, getStatus(marks, doerKey) === "yes");
      considerFineIf(checkerKey, checker, "کنترل", col.label + " — " + dISO, dISO, getStatus(marks, checkerKey) === "yes");
      if (autofined.has(doerKey) && newFines.some((f) => f.id === "auto-" + doerKey)) newLocks.add(doerKey);
      if (autofined.has(checkerKey) && newFines.some((f) => f.id === "auto-" + checkerKey)) newLocks.add(checkerKey);
    });
    scanDay = R.addDays(scanDay, 1);
  }

  // ---- کمک‌تابع دوره‌ای (هفتگی/دوهفته‌ای/ماهانه) ----
  function scanPeriodic(prefix, tasksArr, countIndex, labelForIndex) {
    for (let idx = 0; idx < countIndex; idx++) {
      tasksArr.forEach((item, i) => {
        const periodKey = R.periodKeyFor(prefix, idx, i);
        const doer = R.pickByTier(item.tier, idx + i);
        const checker = R.pickChecker(idx + i + 5, doer);
        const doerDone = item.tasks.every((t, ti) => getStatus(marks, R.periodTaskKey(periodKey, ti)) === "yes");
        const doerMarkKey = R.periodDoerMarkKey(periodKey);
        const checkerKey = R.periodVerifyKey(periodKey);
        const label = labelForIndex(idx);
        considerFineIf(doerMarkKey, doer, "انجام", item.title + " — " + label, label, doerDone);
        considerFineIf(checkerKey, checker, "کنترل", item.title + " — " + label, label, getStatus(marks, checkerKey) === "yes");
        if (newFines.some((f) => f.id === "auto-" + doerMarkKey)) {
          item.tasks.forEach((t, ti) => newLocks.add(R.periodTaskKey(periodKey, ti)));
        }
        if (newFines.some((f) => f.id === "auto-" + checkerKey)) newLocks.add(checkerKey);
      });
    }
  }

  scanPeriodic("w", R.WEEKLY_TASKS, ctx.weekIndex, (wi) => {
    const wkStart = R.addDays(ctx.anchorWeekStart, wi * 7);
    return R.dayKey(wkStart) + "_تا_" + R.dayKey(R.addDays(wkStart, 6));
  });
  scanPeriodic("b", R.BIWEEKLY_TASKS, ctx.biweekIndex, (bi) => {
    const biStart = R.addDays(ctx.anchorWeekStart, bi * 14);
    return R.dayKey(biStart) + "_تا_" + R.dayKey(R.addDays(biStart, 13));
  });
  scanPeriodic("m", R.MONTHLY_TASKS, ctx.monthIndex, (mi) => {
    const mDate = new Date(2026, 8 + mi, 1);
    return R.dayKey(mDate).slice(0, 7);
  });

  // ---- ثبت توی دیتابیس ----
  if (newAutofined.length > 0) {
    for (const k of newAutofined) {
      await client.execute({ sql: "INSERT OR IGNORE INTO autofined (mark_key) VALUES (?)", args: [k] });
    }
  }
  for (const f of newFines) {
    await client.execute({
      sql: `INSERT OR IGNORE INTO fines (id, name, role, reason, date, amount, auto) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      args: [f.id, f.name, f.role, f.reason, f.date, f.amount, f.auto]
    });
  }
  for (const key of newLocks) {
    await client.execute({
      sql: `INSERT INTO task_marks (mark_key, status, locked) VALUES (?, COALESCE((SELECT status FROM task_marks WHERE mark_key = ?), ''), 1)
            ON CONFLICT(mark_key) DO UPDATE SET locked = 1`,
      args: [key, key]
    });
  }

  return { addedFines: newFines.length, notifications };
}

async function getTodayView(now) {
  const ctx = R.computeDateContext(now);
  const marks = await loadAllMarks();
  const items = R.DAILY_COLS.map((col) => {
    const doer = col.whoAt(ctx.todayIdx, ctx.weekIndex);
    const checker = col.checkerAt(ctx.todayIdx, doer, ctx.weekIndex);
    const doerKey = R.dailyDoerKey(ctx.weekIndex, ctx.todayIdx, col.key);
    const checkerKey = R.dailyCheckerKey(ctx.weekIndex, ctx.todayIdx, col.key);
    return {
      key: col.key, label: col.label, tier: col.tier,
      doer, checker,
      doerStatus: getStatus(marks, doerKey), doerLocked: isLocked(marks, doerKey), doerKey,
      checkerStatus: getStatus(marks, checkerKey), checkerLocked: isLocked(marks, checkerKey), checkerKey
    };
  });
  return {
    date: R.dayKey(ctx.eff),
    isPreLaunch: ctx.isPreLaunch,
    anchor: R.dayKey(R.ANCHOR),
    weekIndex: ctx.weekIndex,
    items
  };
}

async function getDailyTableView(now) {
  const ctx = R.computeDateContext(now);
  const marks = await loadAllMarks();
  const days = [];
  for (let d = 0; d < 7; d++) {
    const date = R.addDays(ctx.weekStart, d);
    const cols = R.DAILY_COLS.map((col) => {
      const doer = col.whoAt(d, ctx.weekIndex);
      const checker = col.checkerAt(d, doer, ctx.weekIndex);
      const doerKey = R.dailyDoerKey(ctx.weekIndex, d, col.key);
      const checkerKey = R.dailyCheckerKey(ctx.weekIndex, d, col.key);
      return {
        key: col.key, label: col.label, tier: col.tier, doer, checker,
        doerStatus: getStatus(marks, doerKey), doerLocked: isLocked(marks, doerKey), doerKey,
        checkerStatus: getStatus(marks, checkerKey), checkerLocked: isLocked(marks, checkerKey), checkerKey
      };
    });
    days.push({ dayIndex: d, dayName: R.DAY_NAMES[d], date: R.dayKey(date), isToday: d === ctx.todayIdx, cols });
  }
  return { weekIndex: ctx.weekIndex, weekStart: R.dayKey(ctx.weekStart), weekEnd: R.dayKey(ctx.weekEnd), days };
}

function buildPeriodCard(prefix, item, i, idx, marks) {
  const periodKey = R.periodKeyFor(prefix, idx, i);
  const doer = R.pickByTier(item.tier, idx + i);
  const checker = R.pickChecker(idx + i + 5, doer);
  const checkerKey = R.periodVerifyKey(periodKey);
  const tasks = item.tasks.map((t, ti) => {
    const k = R.periodTaskKey(periodKey, ti);
    return { text: t, key: k, status: getStatus(marks, k), locked: isLocked(marks, k) };
  });
  return {
    key: item.key, periodKey, title: item.title, tier: item.tier, doer, checker,
    tasks,
    checkerKey, checkerStatus: getStatus(marks, checkerKey), checkerLocked: isLocked(marks, checkerKey)
  };
}

async function getWeeklyView(now) {
  const ctx = R.computeDateContext(now);
  const marks = await loadAllMarks();
  const cards = R.WEEKLY_TASKS.map((item, i) => buildPeriodCard("w", item, i, ctx.weekIndex, marks));
  return { weekIndex: ctx.weekIndex, weekStart: R.dayKey(ctx.weekStart), weekEnd: R.dayKey(ctx.weekEnd), cards };
}
async function getBiweeklyView(now) {
  const ctx = R.computeDateContext(now);
  const marks = await loadAllMarks();
  const cards = R.BIWEEKLY_TASKS.map((item, i) => buildPeriodCard("b", item, i, ctx.biweekIndex, marks));
  return { biweekIndex: ctx.biweekIndex, biweekStart: R.dayKey(ctx.biweekStart), biweekEnd: R.dayKey(ctx.biweekEnd), cards };
}
async function getMonthlyView(now) {
  const ctx = R.computeDateContext(now);
  const marks = await loadAllMarks();
  const cards = R.MONTHLY_TASKS.map((item, i) => buildPeriodCard("m", item, i, ctx.monthIndex, marks));
  return { monthIndex: ctx.monthIndex, monthLabel: R.dayKey(ctx.eff).slice(0, 7), cards };
}

async function getFinesView() {
  const res = await client.execute("SELECT * FROM fines ORDER BY created_at ASC");
  const fines = res.rows.map((r) => ({ ...r, auto: !!r.auto }));
  const totals = {};
  R.PEOPLE.forEach((p) => { totals[p] = 0; });
  fines.forEach((f) => { totals[f.name] = (totals[f.name] || 0) + f.amount; });
  return { fines: fines.reverse(), totals };
}

/** ست کردن وضعیت یه select — اگه قفل باشه رد می‌کنه. */
async function setMark(markKey, status, byUser) {
  const res = await client.execute({ sql: "SELECT locked FROM task_marks WHERE mark_key = ?", args: [markKey] });
  if (res.rows.length > 0 && res.rows[0].locked) {
    const err = new Error("این مورد قفل شده و دیگه قابل تغییر نیست.");
    err.code = "LOCKED";
    throw err;
  }
  await client.execute({
    sql: `INSERT INTO task_marks (mark_key, status, updated_by, updated_at, locked) VALUES (?, ?, ?, datetime('now'), 0)
          ON CONFLICT(mark_key) DO UPDATE SET status = excluded.status, updated_by = excluded.updated_by, updated_at = excluded.updated_at`,
    args: [markKey, status, byUser]
  });
}

/**
 * یادآوری عصرگاهی: یه‌بار در روز (توی یه بازهٔ ساعتی مشخص، پیش از ددلاین نیمه‌شب)
 * به هرکسی که هنوز کار امروزش (چه مسئول انجام چه کنترل‌کننده) رو تأیید نکرده یادآوری می‌کنه.
 * با reminder_log دوپلیکیت نمی‌شه، حتی اگه چندبار در همون بازه تیک بخوره.
 */
async function maybeSendEveningReminder(now) {
  const hour = Number(process.env.REMINDER_HOUR || 21); // ساعت محلی (طبق APP_TIMEZONE)
  const windowMin = Number(process.env.REMINDER_WINDOW_MINUTES || 20);
  if (now.getHours() !== hour || now.getMinutes() >= windowMin) return { sent: false, notifications: [] };

  const ctx = R.computeDateContext(now);
  const dateISO = R.dayKey(ctx.eff);
  const reminderKey = "remind-" + dateISO;
  const already = await client.execute({ sql: "SELECT 1 FROM reminder_log WHERE reminder_key = ?", args: [reminderKey] });
  if (already.rows.length > 0) return { sent: false, notifications: [] };

  const today = await getTodayView(now);
  const pending = new Map(); // name -> [labels]
  today.items.forEach((it) => {
    if (it.doerStatus !== "yes" && !it.doerLocked) {
      if (!pending.has(it.doer)) pending.set(it.doer, []);
      pending.get(it.doer).push(it.label + " (انجام)");
    }
    if (it.checkerStatus !== "yes" && !it.checkerLocked) {
      if (!pending.has(it.checker)) pending.set(it.checker, []);
      pending.get(it.checker).push(it.label + " (کنترل)");
    }
  });

  const notifications = [];
  pending.forEach((labels, name) => {
    notifications.push({
      userName: name,
      title: "یادآوری: تا نیمه‌شب وقت داری",
      body: `هنوز تأیید نکردی: ${labels.join("، ")}`
    });
  });

  await client.execute({ sql: "INSERT OR IGNORE INTO reminder_log (reminder_key) VALUES (?)", args: [reminderKey] });
  return { sent: true, notifications };
}

module.exports = {
  runAutoFineScan, getTodayView, getDailyTableView, getWeeklyView, getBiweeklyView, getMonthlyView, getFinesView, setMark,
  maybeSendEveningReminder
};
