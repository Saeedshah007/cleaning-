"use strict";
const webpush = require("web-push");
const { client } = require("./db.js");

let configured = false;
function ensureConfigured() {
  if (configured) return true;
  const pub = process.env.VAPID_PUBLIC_KEY;
  const priv = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || "mailto:admin@example.com";
  if (!pub || !priv) return false;
  webpush.setVapidDetails(subject, pub, priv);
  configured = true;
  return true;
}

async function saveSubscription(userName, subscription) {
  const id = userName + "-" + Buffer.from(subscription.endpoint).toString("base64").slice(-24);
  await client.execute({
    sql: `INSERT INTO push_subscriptions (id, user_name, subscription_json) VALUES (?, ?, ?)
          ON CONFLICT(id) DO UPDATE SET subscription_json = excluded.subscription_json`,
    args: [id, userName, JSON.stringify(subscription)]
  });
}

async function removeSubscription(endpoint) {
  const res = await client.execute("SELECT id, subscription_json FROM push_subscriptions");
  for (const row of res.rows) {
    try {
      const sub = JSON.parse(row.subscription_json);
      if (sub.endpoint === endpoint) {
        await client.execute({ sql: "DELETE FROM push_subscriptions WHERE id = ?", args: [row.id] });
      }
    } catch (e) { /* ignore malformed row */ }
  }
}

async function sendToUser(userName, payload) {
  if (!ensureConfigured()) return { sent: 0, skipped: "vapid-not-configured" };
  const res = await client.execute({
    sql: "SELECT id, subscription_json FROM push_subscriptions WHERE user_name = ?",
    args: [userName]
  });
  let sent = 0;
  for (const row of res.rows) {
    let sub;
    try { sub = JSON.parse(row.subscription_json); } catch (e) { continue; }
    try {
      await webpush.sendNotification(sub, JSON.stringify(payload));
      sent++;
    } catch (err) {
      // اشتراک منقضی/نامعتبر -> پاکش کن
      if (err && (err.statusCode === 404 || err.statusCode === 410)) {
        await client.execute({ sql: "DELETE FROM push_subscriptions WHERE id = ?", args: [row.id] });
      }
    }
  }
  return { sent };
}

module.exports = { ensureConfigured, saveSubscription, removeSubscription, sendToUser };
