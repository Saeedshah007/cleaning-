"use strict";
/**
 * چرخهٔ نظافت خانه — منطق تاریخ و گردش وظایف (سرور).
 * این فایل عیناً از منطق تست‌شدهٔ نسخهٔ آرتیفکت پورت شده تا همون رفتار دقیق
 * (چرخش وزن‌دار، ددلاین‌ها، جریمهٔ خودکار) روی سرور هم عیناً تکرار بشه.
 */

const PEOPLE = ["سعید", "خیبر", "وحید", "احسان"];
const PCOLOR = { "سعید": "#c1622f", "خیبر": "#2f7a9a", "وحید": "#7a5fc4", "احسان": "#a3892f" };
const DAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

function toOurDay(jsDay) { return (jsDay + 1) % 7; } // JS Sun=0 -> یکشنبه=1، Sat=6 -> شنبه=0

function addDays(d, n) { const r = new Date(d); r.setDate(r.getDate() + n); return r; }

// برنامه رسماً از ۱ سپتامبر ۲۰۲۶ شروع می‌شه.
const ANCHOR = new Date(2026, 8, 1); ANCHOR.setHours(0, 0, 0, 0);

function dayKey(d) { return d.toISOString().slice(0, 10); }

// ---- وزن‌دهی سهم هرکس از هر سطح کار ----
const TIER_WEIGHTS = {
  light: { "سعید": 3, "وحید": 2, "احسان": 2, "خیبر": 1 },
  medium: { "سعید": 2, "وحید": 2, "احسان": 2, "خیبر": 2 },
  heavy: { "سعید": 1, "وحید": 2, "احسان": 2, "خیبر": 3 }
};
const BATH_WEIGHTS = { "خیبر": 2, "وحید": 1, "احسان": 1 }; // سعید توی این چرخه نیست
const TIER_LABELS = { light: "سبک", medium: "متوسط", heavy: "سنگین" };

function buildWeightedSequence(weights) {
  const names = Object.keys(weights);
  const state = names.map((n) => ({ name: n, weight: weights[n], current: 0 }));
  const total = state.reduce((s, e) => s + e.weight, 0);
  const seq = [];
  for (let i = 0; i < total; i++) {
    state.forEach((e) => { e.current += e.weight; });
    let best = state[0];
    state.forEach((e) => { if (e.current > best.current) best = e; });
    seq.push(best.name);
    best.current -= total;
  }
  return seq;
}

const SEQ_BY_TIER = {
  light: buildWeightedSequence(TIER_WEIGHTS.light),
  medium: buildWeightedSequence(TIER_WEIGHTS.medium),
  heavy: buildWeightedSequence(TIER_WEIGHTS.heavy)
};
const SEQ_BATH = buildWeightedSequence(BATH_WEIGHTS);

function pickByTier(tier, index) {
  const seq = SEQ_BY_TIER[tier];
  return seq[((index % seq.length) + seq.length) % seq.length];
}
function pickBath(index) {
  return SEQ_BATH[((index % SEQ_BATH.length) + SEQ_BATH.length) % SEQ_BATH.length];
}

const CHECK_SEQ = buildWeightedSequence({ "سعید": 1, "خیبر": 1, "وحید": 1, "احسان": 1 });
function pickChecker(index, exclude) {
  const n = CHECK_SEQ.length;
  let c = CHECK_SEQ[((index % n) + n) % n];
  if (c === exclude) c = CHECK_SEQ[(((index + 1) % n) + n) % n];
  return c;
}

// ---- daily rotation model ----
const DAILY_COLS = [
  { key: "sweep", label: "جارو و طی داخل خونه", tier: "medium",
    whoAt: (d, wIdx) => pickByTier("medium", d + wIdx) },
  { key: "kitchen", label: "آشپزخانه", tier: "heavy",
    whoAt: (d, wIdx) => pickByTier("heavy", d + wIdx) },
  { key: "bath", label: "سرویس بهداشتی مشترک", tier: "heavy",
    whoAt: (d, wIdx) => pickBath(d + wIdx) },
  { key: "out", label: "جاکفشی و مت دم در", tier: "light",
    whoAt: (d, wIdx) => pickByTier("light", d + 3 + wIdx) },
  { key: "water", label: "آبیاری گیاهان بیرون", tier: "light",
    whoAt: (d, wIdx) => pickByTier("light", d + wIdx) }
];
DAILY_COLS.forEach((col, ci) => {
  col.checkerAt = (d, doer, wIdx) => pickChecker(d + wIdx + 5 + ci, doer);
});

const WEEKLY_TASKS = [
  { key: "dust", title: "گردگیری کامل خونه", tier: "light", tasks: ["گردگیری مبل، قفسه و میزها", "تمیز کردن شیشهٔ درها و آینه‌ها"] },
  { key: "trash", title: "شستن سطل‌های زباله", tier: "medium", tasks: ["خالی و شستن سطل آشپزخانه", "خالی و شستن سطل‌های اتاق‌ها"] },
  { key: "kitchendeep", title: "نظافت عمیق آشپزخانه", tier: "heavy", tasks: ["پاک کردن یخچال از داخل", "تمیز کردن اجاق و مایکروویو"] },
  { key: "waterin", title: "آبیاری گیاهان داخل خونه", tier: "light", tasks: ["آب دادن به همهٔ گلدان‌های داخل"] },
  { key: "yard", title: "جارو و شست‌وشوی حیاط", tier: "heavy", tasks: ["جارو کامل ایوان و ورودی", "آب‌پاشی و شست‌وشوی سطح حیاط"] }
];

const BIWEEKLY_TASKS = [
  { key: "prune", title: "هرس گیاهان (داخل و بیرون)", tier: "medium", tasks: ["چیدن برگ و شاخهٔ خشک", "هرس گیاهان بزرگ‌شده و تمیز کردن دور گلدان‌ها"] },
  { key: "mow", title: "چمن‌زنی حیاط", tier: "heavy", tasks: ["چمن‌زنی کامل بک‌یارد", "جمع‌آوری و دورریز چمن‌های چیده‌شده"] },
  { key: "weed", title: "وجین گیاهان", tier: "medium", tasks: ["وجین علف‌های هرز باغچه و گلدان‌ها"] }
];

const MONTHLY_TASKS = [
  { key: "windows", title: "شیشه و پنجره‌ها", tier: "medium", tasks: ["تمیز کردن شیشهٔ پنجره‌های داخل و بیرون"] },
  { key: "filters", title: "فیلتر کولر و هود", tier: "medium", tasks: ["شست‌وشوی فیلتر کولر", "شست‌وشوی فیلتر هود آشپزخانه"] },
  { key: "washer", title: "ماشین لباسشویی", tier: "light", tasks: ["پاک‌سازی و شست‌وشوی داخل ماشین لباسشویی"] },
  { key: "disinfect", title: "گندزدایی سرویس‌های بهداشتی", tier: "heavy", tasks: ["گندزدایی کامل سرویس مشترک", "یادآوری به سعید برای سرویس خودش"] },
  { key: "storage", title: "انباری و گاراژ", tier: "medium", tasks: ["مرتب‌سازی و نظافت انباری/گاراژ"] },
  { key: "backyard", title: "نظافت عمیق بک‌یارد", tier: "heavy", tasks: ["دورریز زباله‌های بزرگ حیاط", "جمع‌آوری برگ‌های ریخته"] }
];

// ---- محاسبات تاریخ نسبت به یک "امروزِ" داده‌شده ----
function computeDateContext(now) {
  const todayRaw = new Date(now); todayRaw.setHours(0, 0, 0, 0);
  const eff = todayRaw.getTime() < ANCHOR.getTime() ? new Date(ANCHOR) : todayRaw;
  const todayIdx = toOurDay(eff.getDay());
  const anchorWeekStart = addDays(ANCHOR, -toOurDay(ANCHOR.getDay()));
  const weekStart = addDays(eff, -todayIdx);
  const weekIndex = Math.round((weekStart - anchorWeekStart) / (7 * 24 * 3600 * 1000));
  const monthIndex = (eff.getFullYear() * 12 + eff.getMonth()) - (2026 * 12 + 8);
  const biweekIndex = Math.floor(weekIndex / 2);
  const weekParity = ((weekIndex % 2) + 2) % 2;
  const biweekStart = weekParity === 1 ? addDays(weekStart, -7) : weekStart;
  const biweekEnd = addDays(biweekStart, 13);
  const weekEnd = addDays(weekStart, 6);
  return {
    now, todayRaw, eff, todayIdx, anchorWeekStart, weekStart, weekEnd,
    weekIndex, monthIndex, biweekIndex, biweekStart, biweekEnd,
    isPreLaunch: todayRaw.getTime() < ANCHOR.getTime(),
    isPastAnchor: todayRaw.getTime() > ANCHOR.getTime()
  };
}

// ---- کلیدهای علامت‌گذاری (مطابق دقیق با نسخهٔ آرتیفکت) ----
function dailyDoerKey(wIdx, dIdx, colKey) { return `d${wIdx}-${dIdx}-${colKey}-sign`; }
function dailyCheckerKey(wIdx, dIdx, colKey) { return `d${wIdx}-${dIdx}-${colKey}-checksign`; }
function periodKeyFor(prefix, idx, i) { return `${prefix}${idx}-${i}`; }
function periodTaskKey(periodKey, taskIdx) { return `${periodKey}-${taskIdx}-sign`; }
function periodVerifyKey(periodKey) { return `${periodKey}-verify-sign`; }
function periodDoerMarkKey(periodKey) { return `${periodKey}-doer`; } // فقط برای دفتر جریمه، شناسهٔ DOM نیست

module.exports = {
  PEOPLE, PCOLOR, DAY_NAMES, TIER_LABELS, ANCHOR,
  DAILY_COLS, WEEKLY_TASKS, BIWEEKLY_TASKS, MONTHLY_TASKS,
  toOurDay, addDays, dayKey,
  pickByTier, pickBath, pickChecker,
  computeDateContext,
  dailyDoerKey, dailyCheckerKey, periodKeyFor, periodTaskKey, periodVerifyKey, periodDoerMarkKey
};
