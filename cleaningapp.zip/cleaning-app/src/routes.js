"use strict";
const express = require("express");
const { client } = require("./db.js");
const { PEOPLE } = require("./rotation.js");
const auth = require("./auth.js");
const engine = require("./engine.js");
const push = require("./push.js");
const { appNow } = require("./tz.js");

const router = express.Router();

// ---------- auth ----------
router.post("/login", async (req, res) => {
  const { name, pin } = req.body || {};
  if (!name || !pin) return res.status(400).json({ error: "اسم و پین لازمه" });
  const ok = await auth.verifyLogin(name, pin);
  if (!ok) return res.status(401).json({ error: "اسم یا پین اشتباهه" });
  auth.setSessionCookie(res, ok);
  res.json({ name: ok });
});

router.post("/logout", (req, res) => {
  auth.clearSessionCookie(res);
  res.json({ ok: true });
});

router.get("/me", auth.requireAuth, (req, res) => {
  res.json({ name: req.user });
});

router.get("/vapid-public-key", (req, res) => {
  res.json({ key: process.env.VAPID_PUBLIC_KEY || null });
});

// همه‌چیز از این‌جا به پایین نیاز به لاگین داره
router.use(auth.requireAuth);

// ---------- views ----------
router.get("/today", async (req, res) => {
  res.json(await engine.getTodayView(appNow()));
});
router.get("/daily", async (req, res) => {
  res.json(await engine.getDailyTableView(appNow()));
});
router.get("/weekly", async (req, res) => {
  res.json(await engine.getWeeklyView(appNow()));
});
router.get("/biweekly", async (req, res) => {
  res.json(await engine.getBiweeklyView(appNow()));
});
router.get("/monthly", async (req, res) => {
  res.json(await engine.getMonthlyView(appNow()));
});
router.get("/fines", async (req, res) => {
  res.json(await engine.getFinesView());
});

// ---------- ثبت وضعیت یه کار ----------
router.post("/mark", async (req, res) => {
  const { key, status } = req.body || {};
  if (!key || !["", "yes", "no"].includes(status)) {
    return res.status(400).json({ error: "ورودی نامعتبر" });
  }
  try {
    await engine.setMark(key, status, req.user);
    res.json({ ok: true });
  } catch (e) {
    if (e.code === "LOCKED") return res.status(423).json({ error: e.message });
    console.error(e);
    res.status(500).json({ error: "خطای سرور" });
  }
});

// ---------- برف‌روبی دسته‌جمعی ----------
router.get("/snow", async (req, res) => {
  const rows = await client.execute("SELECT snow_date, name, status FROM snow");
  const byName = new Map(rows.rows.map((r) => [r.name, r]));
  let date = "";
  for (const r of rows.rows) { if (r.snow_date) { date = r.snow_date; break; } }
  const signers = PEOPLE.map((name) => ({ name, status: byName.has(name) ? byName.get(name).status : "" }));
  res.json({ date, signers });
});
router.post("/snow/date", async (req, res) => {
  const { date } = req.body || {};
  for (const name of PEOPLE) {
    await client.execute({
      sql: `INSERT INTO snow (name, snow_date, status) VALUES (?, ?, '')
            ON CONFLICT(name) DO UPDATE SET snow_date = excluded.snow_date`,
      args: [name, date || null]
    });
  }
  res.json({ ok: true });
});
router.post("/snow/sign", async (req, res) => {
  const { name, status } = req.body || {};
  if (!PEOPLE.includes(name) || !["", "yes", "no"].includes(status)) {
    return res.status(400).json({ error: "ورودی نامعتبر" });
  }
  await client.execute({
    sql: `INSERT INTO snow (name, snow_date, status) VALUES (?, NULL, ?)
          ON CONFLICT(name) DO UPDATE SET status = excluded.status`,
    args: [name, status]
  });
  res.json({ ok: true });
});

// ---------- جریمهٔ دستی ----------
router.post("/fines", async (req, res) => {
  const { name, role, reason, date, amount } = req.body || {};
  if (!PEOPLE.includes(name) || !["انجام", "کنترل"].includes(role)) {
    return res.status(400).json({ error: "ورودی نامعتبر" });
  }
  const id = Date.now() + "-" + Math.random().toString(36).slice(2, 7);
  await client.execute({
    sql: "INSERT INTO fines (id, name, role, reason, date, amount, auto) VALUES (?, ?, ?, ?, ?, ?, 0)",
    args: [id, name, role, reason || "", date || "", Number(amount) || 10]
  });
  res.json({ ok: true, id });
});
router.delete("/fines/:id", async (req, res) => {
  await client.execute({ sql: "DELETE FROM fines WHERE id = ?", args: [req.params.id] });
  res.json({ ok: true });
});

// ---------- پوش ----------
router.post("/push/subscribe", async (req, res) => {
  const sub = req.body;
  if (!sub || !sub.endpoint) return res.status(400).json({ error: "ورودی نامعتبر" });
  await push.saveSubscription(req.user, sub);
  res.json({ ok: true });
});
router.post("/push/unsubscribe", async (req, res) => {
  const { endpoint } = req.body || {};
  if (endpoint) await push.removeSubscription(endpoint);
  res.json({ ok: true });
});

module.exports = router;
