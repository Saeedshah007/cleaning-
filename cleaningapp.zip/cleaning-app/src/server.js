"use strict";
require("dotenv").config();
const path = require("path");
const express = require("express");
const cookieParser = require("cookie-parser");

const { init } = require("./db.js");
const apiRouter = require("./routes.js");
const cronRouter = require("./cron.js");

const app = express();
app.disable("x-powered-by");
app.use(express.json());
app.use(cookieParser());

app.use("/api/cron", cronRouter);
app.use("/api", apiRouter);

app.use(express.static(path.join(__dirname, "..", "public")));
// هر مسیر ناشناخته (غیر /api) رو به index.html بده (اپ تک‌صفحه‌ای)
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, "..", "public", "index.html"));
});

const PORT = process.env.PORT || 3000;

init()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`چرخهٔ نظافت خانه روی پورت ${PORT} بالا اومد.`);
    });
  })
  .catch((e) => {
    console.error("خطا در راه‌اندازی دیتابیس:", e);
    process.exit(1);
  });

module.exports = app;
