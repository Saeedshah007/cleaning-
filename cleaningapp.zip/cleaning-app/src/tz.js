"use strict";
/**
 * سرورهای هاست رایگان (مثل Render) معمولاً روی UTC اجرا می‌شن، نه ساعت محلی خونهٔ شما.
 * چون کل منطق «امروز»، «ددلاین نیمه‌شب» و چرخش وظایف بر پایهٔ getDate()/getDay()/getHours()ی
 * محلیه، باید صریحاً بگیم "الان" از نگاه کدوم منطقهٔ زمانی حساب بشه — وگرنه ددلاین‌ها چند
 * ساعت جابه‌جا می‌شن. این مقدار رو با APP_TIMEZONE (یه IANA timezone مثل America/Toronto یا
 * Asia/Tehran) توی .env تنظیم کن. پیش‌فرض UTC هست — اگه عوضش نکنی، توی لاگ سرور هشدار می‌بینی.
 */

const TZ = process.env.APP_TIMEZONE || "UTC";
let warned = false;

function appNow(base) {
  if (TZ === "UTC" && !warned) {
    warned = true;
    console.warn(
      "[هشدار] APP_TIMEZONE تنظیم نشده و روی UTC مونده. یعنی ددلاین نیمه‌شب و چرخش روزها " +
      "بر اساس نیمه‌شب UTC حساب می‌شه، نه ساعت واقعی خونه. توی .env مقدار مثل " +
      "APP_TIMEZONE=America/Toronto (یا هر منطقهٔ زمانی واقعیِ خودتون) رو ست کن."
    );
  }
  const src = base || new Date();
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: TZ,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
    hour12: false
  }).formatToParts(src);
  const get = (t) => Number(parts.find((p) => p.type === t).value);
  let hour = get("hour");
  if (hour === 24) hour = 0;
  return new Date(get("year"), get("month") - 1, get("day"), hour, get("minute"), get("second"));
}

module.exports = { appNow, TZ };
